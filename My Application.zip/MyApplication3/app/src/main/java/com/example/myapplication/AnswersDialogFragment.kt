package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.api.AnswersResponse
import com.example.myapplication.api.AnswerRequest
import com.example.myapplication.api.RetrofitClient
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AnswersDialogFragment(private val questionId: Int) : DialogFragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var answerInput: TextInputEditText
    private lateinit var submitButton: MaterialButton

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_answers_dialog, container, false)

        recyclerView = view.findViewById(R.id.recyclerViewAnswers)
        progressBar = view.findViewById(R.id.progressBar)
        errorText = view.findViewById(R.id.tvError)
        answerInput = view.findViewById(R.id.etAnswerInput)
        submitButton = view.findViewById(R.id.btnSubmitAnswer)

        recyclerView.layoutManager = LinearLayoutManager(context)

        // Get user ID from shared preferences
        val sharedPref = requireContext().getSharedPreferences("app_prefs", android.content.Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", -1)

        submitButton.setOnClickListener {
            val answerText = answerInput.text.toString().trim()
            if (answerText.isEmpty()) {
                Toast.makeText(requireContext(), "Answer cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (userId == -1) {
                Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val answerRequest = AnswerRequest(
                UserID = userId,
                QuestionID = questionId,
                Body = answerText
            )

            submitAnswer(answerRequest)
        }

        fetchAnswers()

        return view
    }

    private fun submitAnswer(answerRequest: AnswerRequest) {
        progressBar.visibility = View.VISIBLE
        RetrofitClient.apiService.postAnswer(answerRequest)
            .enqueue(object : Callback<Unit> {
                override fun onResponse(call: Call<Unit>, response: Response<Unit>) {
                    progressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(), "Answer posted successfully", Toast.LENGTH_SHORT).show()
                        answerInput.text?.clear()
                        fetchAnswers()
                    } else {
                        Toast.makeText(requireContext(), "Failed to post answer", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<Unit>, t: Throwable) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)

        val window = dialog?.window
        val params = window?.attributes
        params?.width = (resources.displayMetrics.widthPixels * 0.9).toInt() // 90% width
        params?.height = WindowManager.LayoutParams.WRAP_CONTENT // Height wraps content
        window?.attributes = params
    }

    // In AnswersDialogFragment's fetchAnswers() method:
    private fun fetchAnswers() {
        progressBar.visibility = View.VISIBLE
        // Get current user ID from shared preferences
        val sharedPref = requireContext().getSharedPreferences("app_prefs", android.content.Context.MODE_PRIVATE)
        val currentUserId = sharedPref.getInt("USER_ID", -1)

        RetrofitClient.apiService.getAnswers(questionId)
            .enqueue(object : Callback<AnswersResponse> {
                override fun onResponse(
                    call: Call<AnswersResponse>,
                    response: Response<AnswersResponse>
                ) {
                    progressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        val answers = response.body()?.data ?: emptyList()
                        if (answers.isEmpty()) {
                            view?.findViewById<TextView>(R.id.tvNoAnswers)?.visibility = View.VISIBLE
                        } else {
                            view?.findViewById<TextView>(R.id.tvNoAnswers)?.visibility = View.GONE
                            // Pass currentUserId to the adapter
                            recyclerView.adapter = AnswerAdapter(answers, currentUserId)
                        }
                    } else {
                        errorText.text = "Error: ${response.code()}"
                        errorText.visibility = View.VISIBLE
                    }
                }

                override fun onFailure(call: Call<AnswersResponse>, t: Throwable) {
                    progressBar.visibility = View.GONE
                    errorText.text = "Failed to load answers: ${t.localizedMessage}"
                    errorText.visibility = View.VISIBLE
                }
            })
    }
}