package com.example.myapplication.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.AnswersDialogFragment
import com.example.myapplication.QuestionAdapter
import com.example.myapplication.api.QuestionsResponse
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.FragmentUserQuestionsBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserQuestionsFragment : Fragment() {

    private var _binding: FragmentUserQuestionsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: QuestionAdapter
    private var userId: Int = -1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUserQuestionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Read the passed-in user ID; if missing, bail out
        userId = arguments?.getInt("USER_ID", -1) ?: -1
        if (userId == -1) {
            Toast.makeText(requireContext(), "User not authenticated", Toast.LENGTH_SHORT).show()
            requireActivity().onBackPressed()
            return
        }

        setupRecyclerView()
        fetchUserQuestions()
    }

    private fun setupRecyclerView() {
        adapter = QuestionAdapter(emptyList()) { question ->
            // Open the answers dialog for this question
            val dialog = AnswersDialogFragment(question.ID)
            dialog.show(parentFragmentManager, "AnswersDialog")
        }

        binding.recyclerViewUserQuestions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@UserQuestionsFragment.adapter
        }
    }

    private fun fetchUserQuestions() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvEmptyState.visibility = View.GONE
        binding.tvError.visibility = View.GONE

        RetrofitClient.apiService.getUserQuestions(userId)
            .enqueue(object : Callback<QuestionsResponse> {
                override fun onResponse(
                    call: Call<QuestionsResponse>,
                    response: Response<QuestionsResponse>
                ) {
                    binding.progressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        val questions = response.body()?.data ?: emptyList()
                        if (questions.isEmpty()) {
                            binding.tvEmptyState.visibility = View.VISIBLE
                            binding.tvEmptyState.text = "You haven't asked any questions yet"
                        } else {
                            adapter.updateQuestions(questions)
                        }
                    } else {
                        showError("Failed to load questions: ${response.code()}")
                    }
                }

                override fun onFailure(call: Call<QuestionsResponse>, t: Throwable) {
                    binding.progressBar.visibility = View.GONE
                    showError("Network error: ${t.localizedMessage}")
                }
            })
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        binding.tvError.visibility = View.VISIBLE
        binding.tvError.text = message
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
