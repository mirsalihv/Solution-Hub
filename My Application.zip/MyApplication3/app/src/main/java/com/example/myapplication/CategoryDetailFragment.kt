package com.example.myapplication.ui

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.AnswersDialogFragment
import com.example.myapplication.QuestionAdapter
import com.example.myapplication.R
import com.example.myapplication.api.Question
import com.example.myapplication.api.QuestionsResponse
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.FragmentCategoryDetailBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryDetailFragment : Fragment() {

    private var _binding: FragmentCategoryDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: QuestionAdapter
    private var selectedLanguage: String? = null
    private var selectedDifficulty: String? = null
    private var categoryId: Int = -1
    private var categoryName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        categoryId = arguments?.getInt("id") ?: -1
        categoryName = arguments?.getString("name") ?: "Unknown"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoryDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvCategoryName.text = categoryName
        setupRecyclerView()
        fetchQuestions()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_question_list, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_filter -> {
                showFilterDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        adapter = QuestionAdapter(emptyList()) { question ->
            AnswersDialogFragment(question.ID).show(
                parentFragmentManager,
                "AnswersDialog"
            )
        }

        binding.recyclerViewQuestions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@CategoryDetailFragment.adapter
            addItemDecoration(
                DividerItemDecoration(
                    requireContext(),
                    LinearLayoutManager.VERTICAL
                ).apply {
                    setDrawable(
                        ContextCompat.getDrawable(
                            requireContext(),
                            R.drawable.divider
                        )!!
                    )
                }
            )
        }
    }

    private fun showFilterDialog() {
        val languages = listOf("English", "Spanish", "Uzbek", "Russian", "French")
        val difficulties = listOf("Easy", "Medium", "Hard")

        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_filter_questions, null)

        val languageSpinner = dialogView.findViewById<Spinner>(R.id.spinnerLanguage)
        val difficultySpinner = dialogView.findViewById<Spinner>(R.id.spinnerDifficulty)

        ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            listOf("All Languages") + languages
        ).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            languageSpinner.adapter = it
        }

        ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            listOf("All Difficulties") + difficulties
        ).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            difficultySpinner.adapter = it
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Filter Questions")
            .setView(dialogView)
            .setPositiveButton("Apply") { _, _ ->
                selectedLanguage = if (languageSpinner.selectedItemPosition > 0) {
                    languages[languageSpinner.selectedItemPosition - 1]
                } else null

                selectedDifficulty = if (difficultySpinner.selectedItemPosition > 0) {
                    difficulties[difficultySpinner.selectedItemPosition - 1].lowercase()
                } else null

                fetchQuestions()
            }
            .setNegativeButton("Clear") { _, _ ->
                selectedLanguage = null
                selectedDifficulty = null
                fetchQuestions()
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun fetchQuestions() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerViewQuestions.visibility = View.GONE
        binding.tvEmptyState.visibility = View.GONE
        binding.tvError.visibility = View.GONE

        val call = if (selectedLanguage != null || selectedDifficulty != null) {
            // Convert categoryId to String for the filtered endpoint
            RetrofitClient.apiService.getFilteredQuestions(
                language = selectedLanguage,
                difficulty = selectedDifficulty,
                category_id = categoryId.toString()
            )
        } else {
            // Use the integer ID for the regular category endpoint
            RetrofitClient.apiService.getQuestionsByCategory(categoryName)
        }

        call.enqueue(object : Callback<QuestionsResponse> {
            override fun onResponse(
                call: Call<QuestionsResponse>,
                response: Response<QuestionsResponse>
            ) {
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    response.body()?.data?.let { questions ->
                        if (questions.isEmpty()) {
                            showEmptyState()
                        } else {
                            binding.recyclerViewQuestions.visibility = View.VISIBLE
                            adapter.updateQuestions(questions)
                        }
                    } ?: showEmptyState()
                } else {
                    showError("Failed to load questions: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<QuestionsResponse>, t: Throwable) {
                binding.progressBar.visibility = View.GONE
                showError("Network error: ${t.localizedMessage}")
            }
        })
    }

    private fun showEmptyState() {
        binding.tvEmptyState.visibility = View.VISIBLE
        binding.recyclerViewQuestions.visibility = View.GONE
    }

    private fun showError(message: String) {
        binding.tvError.visibility = View.VISIBLE
        binding.tvError.text = message
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}