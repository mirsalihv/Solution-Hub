package com.example.myapplication

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.api.CategoriesResponse
import com.example.myapplication.api.Category
import com.example.myapplication.api.QuestionRequest
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.ActivityMainBinding
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var navController: NavController

    private var userId: Int = -1
    private var categories: List<Category> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        userId = intent.getIntExtra("USER_ID", -1).takeIf { it != -1 }
            ?: getSharedPreferences("app_prefs", MODE_PRIVATE).getInt("USER_ID", -1)

        Toast.makeText(this, "Welcome, user ID: $userId", Toast.LENGTH_LONG).show()

        binding.fab.setOnClickListener {
            showNewQuestionDialog()
        }

        fetchCategories()
    }

    private fun fetchCategories() {
        RetrofitClient.apiService.getCategories().enqueue(object : Callback<CategoriesResponse> {
            override fun onResponse(call: Call<CategoriesResponse>, response: Response<CategoriesResponse>) {
                if (response.isSuccessful) {
                    categories = response.body()?.data ?: emptyList()
                }
            }

            override fun onFailure(call: Call<CategoriesResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Failed to load categories", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showNewQuestionDialog() {
        if (categories.isEmpty()) {
            Toast.makeText(this, "Loading categories...", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_new_question, null)
        val bodyEt = dialogView.findViewById<EditText>(R.id.etBody)
        val categorySpinner = dialogView.findViewById<Spinner>(R.id.spinnerCategory)

        val categoryNames = categories.map { it.Name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categoryNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        AlertDialog.Builder(this)
            .setTitle("Ask a New Question")
            .setView(dialogView)
            .setPositiveButton("Post") { _, _ ->
                val selectedCategory = categories[categorySpinner.selectedItemPosition]
                val bodyText = bodyEt.text.toString().takeIf { it.isNotBlank() } ?: return@setPositiveButton

                val req = QuestionRequest(
                    UserID = userId,
                    CategoryID = selectedCategory.ID,
                    Body = bodyText
                )

                RetrofitClient.apiService.postQuestion(req)
                    .enqueue(object : Callback<ResponseBody> {
                        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                            when {
                                response.isSuccessful -> {
                                    Toast.makeText(this@MainActivity, "Question posted!", Toast.LENGTH_SHORT).show()
                                }
                                response.code() == 400 -> {
                                    Toast.makeText(this@MainActivity, "Explicit words detected. Question is not posted.", Toast.LENGTH_SHORT).show()
                                }
                                else -> {
                                    Toast.makeText(this@MainActivity, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }

                        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                            Toast.makeText(this@MainActivity, "Network error", Toast.LENGTH_SHORT).show()
                        }
                    })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onStart() {
        super.onStart()

        navController = findNavController(R.id.nav_host_fragment_content_main)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            if (destination.id == R.id.questionListFragment) {
                binding.fab.show()
            } else {
                binding.fab.hide()
            }
        }

        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.questionListFragment,
                R.id.categoriesFragment,
                R.id.profileFragment
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        binding.bottomNav.setupWithNavController(navController)
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}

