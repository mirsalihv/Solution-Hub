package com.example.myapplication.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.CategoryAdapter
import com.example.myapplication.R
import com.example.myapplication.api.CategoriesResponse
import com.example.myapplication.api.Category
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.FragmentCategoriesBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoriesFragment : Fragment() {

    private var _binding: FragmentCategoriesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: CategoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoriesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        fetchCategories()
    }

    private fun setupRecyclerView() {
        adapter = CategoryAdapter(emptyList()) { category ->
            val bundle = Bundle().apply {
                putString("name", category.Name)
                putInt("id", category.ID)
            }
            findNavController().navigate(R.id.action_categoriesFragment_to_categoryDetailFragment, bundle)
        }
        binding.recyclerViewCategories.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@CategoriesFragment.adapter
        }
    }

    private fun fetchCategories() {
        binding.progressBar.visibility = View.VISIBLE

        RetrofitClient.apiService.getCategories().enqueue(object : Callback<CategoriesResponse> {
            override fun onResponse(
                call: Call<CategoriesResponse>,
                response: Response<CategoriesResponse>
            ) {
                binding.progressBar.visibility = View.GONE
                if (response.isSuccessful) {
                    val categories = response.body()?.data ?: emptyList()
                    if (categories.isEmpty()) {
                        showEmptyState()
                    } else {
                        adapter.updateCategories(categories)
                        binding.recyclerViewCategories.visibility = View.VISIBLE
                    }
                } else {
                    showError("Failed to load categories: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<CategoriesResponse>, t: Throwable) {
                binding.progressBar.visibility = View.GONE
                showError("Network error: ${t.localizedMessage}")
            }
        })
    }

    private fun showEmptyState() {
        binding.tvEmptyState.visibility = View.VISIBLE
        binding.recyclerViewCategories.visibility = View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        binding.tvError.visibility = View.VISIBLE
        binding.tvError.text = message
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
