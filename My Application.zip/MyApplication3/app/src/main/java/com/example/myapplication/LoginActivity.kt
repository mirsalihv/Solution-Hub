package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.api.LoginRequest
import com.example.myapplication.api.LoginResponse
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.ActivityLoginBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.view.View


class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonLogin.setOnClickListener {
            val email = binding.editTextEmail.text.toString().trim()
            val password = binding.editTextPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show()
            } else {
                performLogin(email, password)
            }
        }

        binding.buttonRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

    }

    private fun performLogin(email: String, password: String) {
        // Show spinner
        binding.progressBar.visibility = View.VISIBLE
        binding.buttonLogin.isEnabled = false

        val request = LoginRequest(email, password)
        RetrofitClient.apiService.login(request).enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                binding.progressBar.visibility = View.GONE
                binding.buttonLogin.isEnabled = true

                if (response.isSuccessful && response.body() != null) {
                    val userId = response.body()!!.id
                    // Optionally persist the user ID (or token) for later
                    getSharedPreferences("app_prefs", MODE_PRIVATE)
                        .edit()
                        .putInt("USER_ID", userId)
                        .apply()

                    Intent(this@LoginActivity, MainActivity::class.java).also {
                        it.putExtra("USER_ID", userId)
                        startActivity(it)
                    }
                    finish()
                } else {
                    Toast.makeText(
                        this@LoginActivity,
                        "Login failed: Invalid credentials",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                binding.progressBar.visibility = View.GONE
                binding.buttonLogin.isEnabled = true
                Toast.makeText(
                    this@LoginActivity,
                    "Login error: ${t.localizedMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
