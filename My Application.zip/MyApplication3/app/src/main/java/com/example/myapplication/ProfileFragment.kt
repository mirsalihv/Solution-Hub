package com.example.myapplication.ui

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication.LoginActivity
import com.example.myapplication.R
import com.example.myapplication.api.*
import com.example.myapplication.databinding.FragmentProfileBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private var userId: Int = -1
    private lateinit var currentProfile: UserProfile

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1) Fragment args 2) Activity intent 3) SharedPrefs
        userId = arguments?.getInt("USER_ID", -1).takeIf { it != -1 }
            ?: requireActivity().intent.getIntExtra("USER_ID", -1).takeIf { it != -1 }
                    ?: requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getInt("USER_ID", -1)

        if (userId == -1) {
            showError("User not authenticated")
            return
        }

        fetchUserProfile(userId)

        binding.fabEditProfile.setOnClickListener {
            showEditProfileDialog()
        }

        binding.btnMyQuestions.setOnClickListener {
            // Build a bundle and navigate using the action ID from nav_graph.xml
            val bundle = Bundle().apply {
                putInt("USER_ID", userId)
            }
            findNavController().navigate(
                R.id.action_profileFragment_to_userQuestionsFragment,
                bundle
            )
        }

        binding.btnLogout.setOnClickListener {
            confirmLogout()
        }
    }

    private fun confirmLogout() {
        AlertDialog.Builder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ -> performLogout() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun performLogout() {
        requireContext()
            .getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .apply()

        startActivity(Intent(requireContext(), LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        requireActivity().finish()
    }

    private fun showEditProfileDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_edit_profile, null)
        val etUsername = dialogView.findViewById<EditText>(R.id.etUsername)
        val etEmail    = dialogView.findViewById<EditText>(R.id.etEmail)
        val etBio      = dialogView.findViewById<EditText>(R.id.etBio)
        val genderSpinner =
            dialogView.findViewById<android.widget.Spinner>(R.id.spinnerGender)

        etUsername.setText(currentProfile.Username)
        etEmail.setText(currentProfile.Email)
        etEmail.isEnabled = false
        etBio.setText(currentProfile.Bio)

        val genderOptions = listOf("Male", "Female")
        android.widget.ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            genderOptions
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            genderSpinner.adapter = adapter
        }
        genderSpinner.setSelection(
            genderOptions.indexOfFirst { it.equals(currentProfile.Gender, true) }
                .let { if (it >= 0) it else 0 }
        )

        AlertDialog.Builder(requireContext())
            .setTitle("Edit Profile")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val req = UpdateProfileRequest(
                    username = etUsername.text.toString(),
                    email    = currentProfile.Email,
                    bio      = etBio.text.toString(),
                    gender   = genderSpinner.selectedItem as String
                )
                updateProfile(userId, req)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateProfile(userId: Int, req: UpdateProfileRequest) {
        binding.progressBar.visibility = View.VISIBLE
        RetrofitClient.apiService.updateUserProfile(userId, req)
            .enqueue(object : Callback<UserProfileResponse> {
                override fun onResponse(
                    call: Call<UserProfileResponse>,
                    resp: Response<UserProfileResponse>
                ) {
                    binding.progressBar.visibility = View.GONE
                    if (resp.isSuccessful) {
                        Toast.makeText(requireContext(),
                            "Profile updated successfully", Toast.LENGTH_SHORT).show()
                        fetchUserProfile(userId)
                    } else {
                        showError("Failed to update: ${resp.code()}")
                    }
                }
                override fun onFailure(call: Call<UserProfileResponse>, t: Throwable) {
                    binding.progressBar.visibility = View.GONE
                    showError("Network error: ${t.localizedMessage}")
                }
            })
    }

    private fun fetchUserProfile(userId: Int) {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvError.visibility = View.GONE

        RetrofitClient.apiService.getUserProfile(userId)
            .enqueue(object : Callback<UserProfileResponse> {
                override fun onResponse(
                    call: Call<UserProfileResponse>,
                    resp: Response<UserProfileResponse>
                ) {
                    binding.progressBar.visibility = View.GONE
                    if (resp.isSuccessful) {
                        resp.body()?.data?.let { profile ->
                            currentProfile = profile
                            displayProfile(profile)
                        } ?: showError("No profile data")
                    } else {
                        showError("Failed to load: ${resp.code()}")
                    }
                }
                override fun onFailure(call: Call<UserProfileResponse>, t: Throwable) {
                    binding.progressBar.visibility = View.GONE
                    showError("Network error: ${t.localizedMessage}")
                }
            })
    }

    private fun displayProfile(profile: UserProfile) = with(binding) {
        tvUsername.text     = profile.Username
        chipReputation.text = "Reputation: ${profile.Reputation}"
        tvEmail.text        = profile.Email
        tvGender.text       = profile.Gender
        tvBio.text          = profile.Bio.ifEmpty { "No bio added" }
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        binding.tvError.visibility = View.VISIBLE
        binding.tvError.text       = message
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
