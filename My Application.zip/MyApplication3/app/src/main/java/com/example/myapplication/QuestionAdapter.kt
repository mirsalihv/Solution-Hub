package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.api.Question
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.*

class QuestionAdapter(
    private var questions: List<Question>,
    private val onQuestionClick: (Question) -> Unit
) : RecyclerView.Adapter<QuestionAdapter.QuestionViewHolder>() {

    class QuestionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val questionBody: TextView = itemView.findViewById(R.id.tvQuestionBody)
        val difficultyChip: Chip = itemView.findViewById(R.id.chipDifficulty)
        val timestamp: TextView = itemView.findViewById(R.id.tvTimestamp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_question, parent, false)
        return QuestionViewHolder(view)
    }

    override fun onBindViewHolder(holder: QuestionViewHolder, position: Int) {
        val question = questions[position]

        // Set question text
        holder.questionBody.text = question.Body

        // Set difficulty chip
        question.Difficulty?.let { difficulty ->
            holder.difficultyChip.text = difficulty.replaceFirstChar { it.uppercase() }
            when (difficulty.lowercase()) {
                "easy" -> {
                    holder.difficultyChip.setChipBackgroundColorResource(R.color.easy_green)
                    holder.difficultyChip.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
                }
                "medium" -> {
                    holder.difficultyChip.setChipBackgroundColorResource(R.color.medium_yellow)
                    holder.difficultyChip.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
                }
                "hard" -> {
                    holder.difficultyChip.setChipBackgroundColorResource(R.color.hard_red)
                    holder.difficultyChip.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
                }
                else -> {
                    holder.difficultyChip.setChipBackgroundColorResource(R.color.gray)
                    holder.difficultyChip.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
                }
            }
            holder.difficultyChip.visibility = View.VISIBLE
        } ?: run {
            holder.difficultyChip.visibility = View.GONE
        }

        // Format the creation timestamp
        holder.timestamp.text = formatQuestionTime(question.CreatedAt)

        // Click listener
        holder.itemView.setOnClickListener {
            onQuestionClick(question)
        }
    }

    private fun formatQuestionTime(createdAt: String?): String {
        if (createdAt == null) return "Recently"

        return try {
            val dateTime = OffsetDateTime.parse(createdAt)
            val now = OffsetDateTime.now(ZoneId.systemDefault())
            val diffInMillis = ChronoUnit.MILLIS.between(dateTime, now)

            when {
                diffInMillis < 60_000 -> "Just now"
                diffInMillis < 60 * 60_000 -> "${diffInMillis / 60_000}m ago"
                diffInMillis < 24 * 60 * 60_000 -> "${diffInMillis / 3_600_000}h ago"
                diffInMillis < 7 * 24 * 60 * 60_000 -> "${diffInMillis / (24 * 3_600_000)}d ago"
                else -> dateTime.format(DateTimeFormatter.ofPattern("MMM d"))
            }
        } catch (e: Exception) {
            Log.e("QuestionAdapter", "Error parsing date: ${e.message}")
            "Recently"
        }
    }

    override fun getItemCount(): Int = questions.size

    fun updateQuestions(newQuestions: List<Question>) {
        questions = newQuestions
        notifyDataSetChanged()
    }
}