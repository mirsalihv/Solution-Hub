package com.example.myapplication.ui

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.AnswersDialogFragment
import com.example.myapplication.QuestionAdapter
import com.example.myapplication.R
import com.example.myapplication.api.Question
import com.example.myapplication.api.QuestionsResponse
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.FragmentQuestionListBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuestionListFragment : Fragment() {

    private var _binding: FragmentQuestionListBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: QuestionAdapter
    private var selectedLanguage: String? = null
    private var selectedDifficulty: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true) // Enable menu in fragment
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuestionListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        fetchQuestions()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_question_list, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_filter -> {
                showFilterDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        adapter = QuestionAdapter(emptyList()) { question ->
            val dialog = AnswersDialogFragment(question.ID)
            dialog.show(parentFragmentManager, "AnswersDialog")
        }

        binding.recyclerViewQuestions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@QuestionListFragment.adapter
            addItemDecoration(
                DividerItemDecoration(
                    requireContext(),
                    LinearLayoutManager.VERTICAL
                ).apply {
                    setDrawable(
                        ContextCompat.getDrawable(
                            requireContext(),
                            R.drawable.divider
                        )!!
                    )
                }
            )
        }
    }

    fun showFilterDialog() {
        val languages = listOf("English", "Spanish", "Uzbek", "Russian", "French")
        val difficulties = listOf("Easy", "Medium", "Hard")

        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_filter_questions, null)

        val languageSpinner = dialogView.findViewById<Spinner>(R.id.spinnerLanguage)
        val difficultySpinner = dialogView.findViewById<Spinner>(R.id.spinnerDifficulty)

        val languageAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            listOf("All Languages") + languages
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        languageSpinner.adapter = languageAdapter

        val difficultyAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            listOf("All Difficulties") + difficulties
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        difficultySpinner.adapter = difficultyAdapter

        AlertDialog.Builder(requireContext())
            .setTitle("Filter Questions")
            .setView(dialogView)
            .setPositiveButton("Apply") { _, _ ->
                selectedLanguage = if (languageSpinner.selectedItemPosition > 0) {
                    languages[languageSpinner.selectedItemPosition - 1]
                } else null

                selectedDifficulty = if (difficultySpinner.selectedItemPosition > 0) {
                    difficulties[difficultySpinner.selectedItemPosition - 1].lowercase()
                } else null

                fetchQuestions()
            }
            .setNegativeButton("Clear") { _, _ ->
                selectedLanguage = null
                selectedDifficulty = null
                fetchQuestions()
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun fetchQuestions() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvEmptyState.visibility = View.GONE
        binding.tvError.visibility = View.GONE

        val call = if (selectedLanguage != null || selectedDifficulty != null) {
            RetrofitClient.apiService.getFilteredQuestions(selectedLanguage, selectedDifficulty)
        } else {
            RetrofitClient.apiService.getQuestions()
        }

        call.enqueue(object : Callback<QuestionsResponse> {
            override fun onResponse(
                call: Call<QuestionsResponse>,
                response: Response<QuestionsResponse>
            ) {
                binding.progressBar.visibility = View.GONE
                if (response.isSuccessful) {
                    val questions = response.body()?.data ?: emptyList()
                    if (questions.isEmpty()) {
                        showEmptyState()
                    } else {
                        binding.recyclerViewQuestions.visibility = View.VISIBLE
                        adapter.updateQuestions(questions)
                    }
                } else {
                    showError("Failed to load questions: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<QuestionsResponse>, t: Throwable) {
                binding.progressBar.visibility = View.GONE
                showError("Network error: ${t.localizedMessage}")
            }
        })
    }

    private fun showEmptyState() {
        binding.tvEmptyState.visibility = View.VISIBLE
        binding.recyclerViewQuestions.visibility = View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        binding.tvError.visibility = View.VISIBLE
        binding.tvError.text = message
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
