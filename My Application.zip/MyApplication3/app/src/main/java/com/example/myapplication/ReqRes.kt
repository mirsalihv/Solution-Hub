package com.example.myapplication.api

data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val id: Int,
    val username: String
)

data class Answer(
    val ID: Int,
    val UserID: Int,
    val QuestionID: Int,
    val Body: String,
    val CreatedAt: String,
    val User: User
)


data class AnswerRequest(
    val UserID: Int,
    val QuestionID: Int,
    val Body: String,
    val AnswerCount: Int = 0
)


data class User(
    val ID: Int,
    val Username: String,
    val Email: String,
    val Bio: String,
    val Reputation: Int
)

data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String,
    val bio: String,
    val gender: String
)

data class UpdateProfileRequest(
    val username: String,
    val email: String,
    val bio: String,
    val gender: String
)

data class QuestionRequest(
    val UserID: Int,
    val CategoryID: Int,
    val Body: String
)

data class QuestionsResponse(
    val data: List<Question>,
    val is_success: Boolean
)

data class Question(
    val ID: Int,
    val Body: String,
    val CreatedAt: String,
    val Difficulty: String,
    val Language: String
    // you can add other fields if you need them later
)

data class CategoriesResponse(
    val data: List<Category>,
    val is_success: Boolean
)

data class Category(
    val ID: Int,
    val Name: String
)

data class UserProfileResponse(
    val data: UserProfile,
    val is_success: Boolean
)

data class UserProfile(
    val ID: Int,
    val Username: String,
    val Email: String,
    val Password: String, // Note: You shouldn't display this in the UI
    val Bio: String,
    val Reputation: Int,
    val Gender: String,
    val Image: String
)