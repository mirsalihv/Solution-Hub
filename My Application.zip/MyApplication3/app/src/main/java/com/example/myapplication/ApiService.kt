package com.example.myapplication.api

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @POST("users/login")
    fun login(@Body loginRequest: LoginRequest): Call<LoginResponse>

    @GET("questions")
    fun getQuestions(): Call<QuestionsResponse>

    @GET("categories")
    fun getCategories(): Call<CategoriesResponse>

    @GET("users/{user_id}")  // Changed from POST to GET
    fun getUserProfile(
        @Path("user_id") userId: Int  // No @Body needed for GET
    ): Call<UserProfileResponse>

    @GET("/questions/category/{category_name}")
    fun getQuestionsByCategory(
        @Path("category_name") categoryName: String
    ): Call<QuestionsResponse>


    @POST("/users/signup")
    fun signup(@Body request: RegisterRequest): Call<Void>

    @PUT("users/{user_id}")
    fun updateUserProfile(
        @Path("user_id") userId: Int,
        @Body updatedProfile: UpdateProfileRequest
    ): Call<UserProfileResponse>

    @POST("/questions")
    fun postQuestion(@Body question: QuestionRequest): Call<ResponseBody>

    @GET("questions/{question_id}/answers")
    fun getAnswers(@Path("question_id") questionId: Int): Call<AnswersResponse>

    @POST("answers")
    fun postAnswer(@Body answer: AnswerRequest): Call<Unit>

    @GET("questions/filter")
    fun getFilteredQuestions(
        @Query("language") language: String?,
        @Query("difficulty") difficulty: String?
    ): Call<QuestionsResponse>

    @GET("questions/filter")
    fun getFilteredQuestions(
        @Query("language") language: String?,
        @Query("difficulty") difficulty: String?,
        @Query("category_id") category_id: String?

    ): Call<QuestionsResponse>

    @GET("questions/user/{user_id}")
    fun getUserQuestions(@Path("user_id") userId: Int): Call<QuestionsResponse>

}

data class AnswersResponse(val data: List<Answer>)