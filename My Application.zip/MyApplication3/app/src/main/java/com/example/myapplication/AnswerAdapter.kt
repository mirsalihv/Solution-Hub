package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.api.Answer

class AnswerAdapter(
    private val answers: List<Answer>,
    private val currentUserId: Int // Add current user ID parameter
) : RecyclerView.Adapter<AnswerAdapter.AnswerViewHolder>() {

    class AnswerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val body: TextView = itemView.findViewById(R.id.tvAnswerBody)
        val username: TextView = itemView.findViewById(R.id.tvUsername)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnswerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_answer, parent, false)
        return AnswerViewHolder(view)
    }

    override fun onBindViewHolder(holder: AnswerViewHolder, position: Int) {
        val answer = answers[position]
        holder.body.text = answer.Body

        // Check if the answer belongs to the current user
        if (answer.User.ID == currentUserId) {
            holder.username.text = "You"
            // Set different color for "You" (use your color resource)
            val color = ContextCompat.getColor(holder.itemView.context, R.color.your_special_color)
            holder.username.setTextColor(color)
        } else {
            holder.username.text = "by ${answer.User.Username}"
            // Set default color
            val color = ContextCompat.getColor(holder.itemView.context, R.color.default_username_color)
            holder.username.setTextColor(color)
        }
    }

    override fun getItemCount(): Int = answers.size
}